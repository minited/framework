document.documentElement.classList.add("js");

document.querySelectorAll(".carousel").forEach((carousel) => {
  const track = carousel.querySelector(".carousel__track");
  const prevBtn = carousel.querySelector(".carousel__control--prev");
  const nextBtn = carousel.querySelector(".carousel__control--next");
  const status = carousel.querySelector(".carousel__status");
  const slides = Array.from(carousel.querySelectorAll(".carousel__slide"));

  if (!track || !prevBtn || !nextBtn || !slides.length) return;

  const getStep = () => slides[0]?.clientWidth || track.clientWidth;

  const getCurrentIndex = () => {
    const step = getStep();
    if (!step) return 0;
    return Math.round(track.scrollLeft / step);
  };

  const updateStatus = () => {
    if (!status) return;
    const index = Math.max(0, Math.min(slides.length - 1, getCurrentIndex()));
    status.textContent = `Slide ${index + 1} of ${slides.length}`;
  };

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const move = (dir) => {
    const step = getStep();
    const max = track.scrollWidth - track.clientWidth;
    const next = track.scrollLeft + step * dir;
    const target = dir === 1 && next > max ? 0 : dir === -1 && next < 0 ? max : next;

    track.scrollTo({
      left: target,
      behavior: prefersReducedMotion ? "instant" : "smooth"
    });

    window.setTimeout(updateStatus, 250);
  };

  prevBtn.addEventListener("click", () => move(-1));
  nextBtn.addEventListener("click", () => move(1));

  updateStatus();
  
  let resizeTimer;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const step = getStep();
      const index = Math.round(track.scrollLeft / step);
      track.scrollTo({ left: index * step, behavior: "instant" });
    }, 150);
  });
});
